import { TestBed } from '@angular/core/testing';

import { ProductpageService } from './productpage.service';

describe('ProductpageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductpageService = TestBed.get(ProductpageService);
    expect(service).toBeTruthy();
  });
});

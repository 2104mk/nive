export interface Iproductpage{
    productid:number;
   productname:String;
   productimage:String;
   productprice:number;
}
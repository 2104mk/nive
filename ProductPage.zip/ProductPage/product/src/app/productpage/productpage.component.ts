import { ProductpageService } from '../service/productpage.service';
import { Component, OnInit } from '@angular/core';
import { Iproductpage } from './model/productpage.model';
@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {

  productpage:Iproductpage[];
  productpagedetail:Iproductpage;
  productid:number;
  productname:String;
  productimage:String;
  productprice:number;

  constructor(private service:ProductpageService) { 
    
  }

  ngOnInit() {
    this.service.getProductPage().subscribe(data=>this.productpage=data); 
      }
  getProduct(){
    
    let arr=this.productpage.filter(p=>p.productid==this.productid);
    if(arr.length>0){
     
      arr.map(p=>this.productpagedetail=p);
      this.productid=this.productpagedetail.productid;
      this.productname=this.productpagedetail.productname;
      this.productimage=this.productpagedetail.productimage;
      this.productprice=this.productpagedetail.productprice;
      
    }
  }


}
